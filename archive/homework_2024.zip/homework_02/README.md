# 2. házi feladat - Xtext

A házi feladat kiírása [itt található](HaziFeladat.md).

# 2nd homework - Xtext

The homework assignment can be [viewed here](Homework.md).
