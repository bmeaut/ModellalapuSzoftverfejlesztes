# 3. házi feladat - ANTLR

Az ANTLR házi feladat kiírása [itt található](./ANTLR_HW/ANTLR.md).

# 3. házi feladat - LLVM

Az LLVM házi feladat kiírása [itt található](./LLVM_HW/LLVM.md).



# 3rd homework - ANTLR

The ANTLR homework assignment can be [viewed here](./ANTLR_HW/ANTLR_EN.md).

# 3rd homework - LLVM

The LLVM homework assignment can be [viewed here](./LLVM_HW/LLVM_EN.md).