package statemachines;

public class Program {

	public static void main(String[] args) {
		var lamp = new Lamp();
		lamp.Flick();
		lamp.Flick();
		lamp.Flick();
		lamp.Flick();
	}

}
