## Modellalapú szoftverfejlesztés tárgy
## 4. Gyakorlat: Szöveges szakterületi nyelvek IDE támogatása

### A gyakorlat célja
A gyakorlat célja az Xtext és Xtend keretrendszer segítségével egy egyszerű szöveges DSL-hez fordítót és kódgenerátort, valamint Eclipse fejlesztőkörnyezethez (IDE – Integrated Development Environment) támogatást készíteni.

A gyakorlathoz tartozó összes információ a részletes [útmutatóban](https://github.com/bmeaut/ModellalapuSzoftverfejlesztes/raw/master/practice/practice_04/Modellalap%C3%BA%20szoftverfejleszt%C3%A9s_GY04_utmutato.pdf) található.

### A futtatáshoz szükséges eszközök
- [Eclipse IDE for Java and DSL Developers](https://www.eclipse.org/downloads/packages/release/2023-03/r/eclipse-ide-java-and-dsl-developers)
	- [JDK](https://adoptium.net/) (ha nem lenne)
