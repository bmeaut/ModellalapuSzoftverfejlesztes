## Modellalapú szoftverfejlesztés tárgy
## 2. Gyakorlat: Roslyn és MPS

**Az elhangzott előadás  [diasor](https://github.com/bmeaut/ModellalapuSzoftverfejlesztes/raw/master/practice/practice_02/Modellalap%C3%BA%20szoftverfejleszt%C3%A9s_GY02.pdf)**

**A két témakör demójához szükséges projektek, valamint a beüzemeléshez szükséges információk az almappában találhatóak.**
