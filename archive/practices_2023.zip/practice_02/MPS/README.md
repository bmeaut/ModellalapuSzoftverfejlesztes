# vsr_demo
Educational version of Music Visulasier Domain Specific System (VSR).

### MPS
Project backwards and forward compatibility between MPS versions is not always guaranteed. For this repo I used v2022.2.

### Hardware demo
https://www.youtube.com/watch?v=KRuO5h96djY

### Full VSR repo
https://github.com/akosbalogh01/vsr
