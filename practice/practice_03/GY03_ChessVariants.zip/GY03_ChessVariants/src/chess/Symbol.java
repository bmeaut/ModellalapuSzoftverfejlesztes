package chess;

public class Symbol {
    public String name;
    public String type;     // Itt csak string a típus (pl. "player", "piece"), de egy klasszikusabb nyelvnél típusrendszerre lenne szükségünk

    public Symbol(String name, String type) {
        this.name = name;
        this.type = type;
    }

    @Override public String toString() {
        return name + " : " + type;
    }
}
