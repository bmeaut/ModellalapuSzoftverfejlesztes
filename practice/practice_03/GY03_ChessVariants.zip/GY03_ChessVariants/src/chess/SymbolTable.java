package chess;

import java.util.HashMap;
import java.util.Map;

// No scoping in this language
public class SymbolTable {
    private Map<String, Symbol> table = new HashMap<>();

    public Symbol lookupSymbol(String name) {
        if (table.containsKey(name))
            return table.get(name);

        return null;
    }

    public boolean insertSymbol(Symbol symbol) {
        if (table.containsKey(symbol.name)) {
            System.out.println("symbol '" + symbol.name + "' already exists");
            return false;
        }

        table.put(symbol.name, symbol);
        return true;
    }

    @Override public String toString() {
        StringBuilder bld = new StringBuilder();
        bld.append("---------------\n");
        for (var symbol : table.values()) {
            bld.append(symbol.toString()).append("\n");
        }
        return bld.toString();
    }
}
