﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataControlFlowDemo
{
    public class DemoClass
    {
        private const int DummyConst = 10;

        public void Test_DataFlowAnalysis()
        {
            string x = "5";
            int y = 10;
            int z = 25;
            x = "30";
        }

        public int Test_ControlFlowAnalysis()
        {
            var random = new Random().Next(1, 100);
            if (random >= 50)
            {
                return 15;
            }

            if (random >= 75)
            {
                return DummyConst;
            }
            
            return random;
        }
    }
}
