﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;

namespace ScriptingAPI
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            await Scripting_Eval_FixExpr();
            //  for(int i=0;i<10;i++) Console.WriteLine($"Counter: {i}");
            //await Scripting_Eval_DynExpr();
            //await Scripting_Eval_DynExprWithUsing();
            //await Scripting_Eval_DynExprWithErrorHandling();
            //await Scripting_MultiStep();

            Console.ReadLine();
        }

        static async Task Scripting_Eval_FixExpr()
        {
            var result = await CSharpScript.EvaluateAsync("5+4*2");
            Console.WriteLine(result);
        }

        static async Task Scripting_Eval_DynExpr()
        {
            while (true)
            {
                var codeToEval = Console.ReadLine();
                var result = await CSharpScript.EvaluateAsync(codeToEval);
	        Console.WriteLine(result);
            }
        }

        static async Task Scripting_Eval_DynExprWithUsing()
        {

            while (true)
            {
                    var codeToEval = Console.ReadLine();
                    var result = await CSharpScript.EvaluateAsync(codeToEval, ScriptOptions.Default.WithImports("System"));
                    Console.WriteLine(result);
            }
        }

        static async Task Scripting_Eval_DynExprWithErrorHandling()
        {
            while (true)
            {
                try
                {

                    var codeToEval = Console.ReadLine();
                    var result = await CSharpScript.EvaluateAsync(codeToEval, ScriptOptions.Default.WithImports("System"));
                    Console.WriteLine(result);
                }
                catch (CompilationErrorException e)
                {
                    Console.WriteLine(string.Join(Environment.NewLine, e.Diagnostics));
                }
            }
        }

        static async Task Scripting_MultiStep()
        {
            var state = await CSharpScript.RunAsync("int a = 1;");
            state = await state.ContinueWithAsync("int b = 2;");
            state = await state.ContinueWithAsync("int c = a + b;");
            state = await state.ContinueWithAsync("c");
            Console.WriteLine(state.ReturnValue);
        }

    }
}
