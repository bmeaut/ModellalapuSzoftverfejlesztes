package tinyscript;

// This class is an example of Java code from the input.tys file; whitespace formatting may vary
public class TinyScriptOutputExample {
    public static int add(int a, int b) {
        return a + b;
    }

    public static void print(String s) {
    }

    public static void main(String[] args) {
        int a = 1 + 2 + 3;
        var b = a * 2;

        while (b < 15) {
            b = b + 1;
            print("b increased");
        }

        if (true) {
            add(1, 2);
        }
        else {
            print("not true");
        }

    }
}