/**
 */
package socialNetworkPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Post</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see socialNetworkPackage.SocialNetworkPackagePackage#getPost()
 * @model
 * @generated
 */
public interface Post extends EObject {
} // Post
