/**
 */
package socialNetworkPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Message Post</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link socialNetworkPackage.MessagePost#getPublicannouncement <em>Publicannouncement</em>}</li>
 * </ul>
 *
 * @see socialNetworkPackage.SocialNetworkPackagePackage#getMessagePost()
 * @model
 * @generated
 */
public interface MessagePost extends Post {
	/**
	 * Returns the value of the '<em><b>Publicannouncement</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link socialNetworkPackage.PublicAnnouncement#getMessagepost <em>Messagepost</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Publicannouncement</em>' reference.
	 * @see #setPublicannouncement(PublicAnnouncement)
	 * @see socialNetworkPackage.SocialNetworkPackagePackage#getMessagePost_Publicannouncement()
	 * @see socialNetworkPackage.PublicAnnouncement#getMessagepost
	 * @model opposite="messagepost"
	 * @generated
	 */
	PublicAnnouncement getPublicannouncement();

	/**
	 * Sets the value of the '{@link socialNetworkPackage.MessagePost#getPublicannouncement <em>Publicannouncement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Publicannouncement</em>' reference.
	 * @see #getPublicannouncement()
	 * @generated
	 */
	void setPublicannouncement(PublicAnnouncement value);

} // MessagePost
