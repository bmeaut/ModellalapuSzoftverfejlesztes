/**
 */
package socialNetworkPackage;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Public Announcement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link socialNetworkPackage.PublicAnnouncement#getMessagepost <em>Messagepost</em>}</li>
 * </ul>
 *
 * @see socialNetworkPackage.SocialNetworkPackagePackage#getPublicAnnouncement()
 * @model
 * @generated
 */
public interface PublicAnnouncement extends Post {
	/**
	 * Returns the value of the '<em><b>Messagepost</b></em>' reference list.
	 * The list contents are of type {@link socialNetworkPackage.MessagePost}.
	 * It is bidirectional and its opposite is '{@link socialNetworkPackage.MessagePost#getPublicannouncement <em>Publicannouncement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Messagepost</em>' reference list.
	 * @see socialNetworkPackage.SocialNetworkPackagePackage#getPublicAnnouncement_Messagepost()
	 * @see socialNetworkPackage.MessagePost#getPublicannouncement
	 * @model opposite="publicannouncement"
	 * @generated
	 */
	EList<MessagePost> getMessagepost();

} // PublicAnnouncement
