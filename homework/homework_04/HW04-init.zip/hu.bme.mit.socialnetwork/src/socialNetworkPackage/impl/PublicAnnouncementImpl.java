/**
 */
package socialNetworkPackage.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import socialNetworkPackage.MessagePost;
import socialNetworkPackage.PublicAnnouncement;
import socialNetworkPackage.SocialNetworkPackagePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Public Announcement</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link socialNetworkPackage.impl.PublicAnnouncementImpl#getMessagepost <em>Messagepost</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PublicAnnouncementImpl extends PostImpl implements PublicAnnouncement {
	/**
	 * The cached value of the '{@link #getMessagepost() <em>Messagepost</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMessagepost()
	 * @generated
	 * @ordered
	 */
	protected EList<MessagePost> messagepost;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PublicAnnouncementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SocialNetworkPackagePackage.Literals.PUBLIC_ANNOUNCEMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MessagePost> getMessagepost() {
		if (messagepost == null) {
			messagepost = new EObjectWithInverseResolvingEList<MessagePost>(MessagePost.class, this, SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST, SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT);
		}
		return messagepost;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getMessagepost()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST:
				return ((InternalEList<?>)getMessagepost()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST:
				return getMessagepost();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST:
				getMessagepost().clear();
				getMessagepost().addAll((Collection<? extends MessagePost>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST:
				getMessagepost().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST:
				return messagepost != null && !messagepost.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PublicAnnouncementImpl
