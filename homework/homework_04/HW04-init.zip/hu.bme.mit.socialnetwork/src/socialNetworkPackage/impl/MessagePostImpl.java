/**
 */
package socialNetworkPackage.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import socialNetworkPackage.MessagePost;
import socialNetworkPackage.PublicAnnouncement;
import socialNetworkPackage.SocialNetworkPackagePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Message Post</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link socialNetworkPackage.impl.MessagePostImpl#getPublicannouncement <em>Publicannouncement</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MessagePostImpl extends PostImpl implements MessagePost {
	/**
	 * The cached value of the '{@link #getPublicannouncement() <em>Publicannouncement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPublicannouncement()
	 * @generated
	 * @ordered
	 */
	protected PublicAnnouncement publicannouncement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MessagePostImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SocialNetworkPackagePackage.Literals.MESSAGE_POST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PublicAnnouncement getPublicannouncement() {
		if (publicannouncement != null && publicannouncement.eIsProxy()) {
			InternalEObject oldPublicannouncement = (InternalEObject)publicannouncement;
			publicannouncement = (PublicAnnouncement)eResolveProxy(oldPublicannouncement);
			if (publicannouncement != oldPublicannouncement) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT, oldPublicannouncement, publicannouncement));
			}
		}
		return publicannouncement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PublicAnnouncement basicGetPublicannouncement() {
		return publicannouncement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPublicannouncement(PublicAnnouncement newPublicannouncement, NotificationChain msgs) {
		PublicAnnouncement oldPublicannouncement = publicannouncement;
		publicannouncement = newPublicannouncement;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT, oldPublicannouncement, newPublicannouncement);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPublicannouncement(PublicAnnouncement newPublicannouncement) {
		if (newPublicannouncement != publicannouncement) {
			NotificationChain msgs = null;
			if (publicannouncement != null)
				msgs = ((InternalEObject)publicannouncement).eInverseRemove(this, SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST, PublicAnnouncement.class, msgs);
			if (newPublicannouncement != null)
				msgs = ((InternalEObject)newPublicannouncement).eInverseAdd(this, SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST, PublicAnnouncement.class, msgs);
			msgs = basicSetPublicannouncement(newPublicannouncement, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT, newPublicannouncement, newPublicannouncement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT:
				if (publicannouncement != null)
					msgs = ((InternalEObject)publicannouncement).eInverseRemove(this, SocialNetworkPackagePackage.PUBLIC_ANNOUNCEMENT__MESSAGEPOST, PublicAnnouncement.class, msgs);
				return basicSetPublicannouncement((PublicAnnouncement)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT:
				return basicSetPublicannouncement(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT:
				if (resolve) return getPublicannouncement();
				return basicGetPublicannouncement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT:
				setPublicannouncement((PublicAnnouncement)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT:
				setPublicannouncement((PublicAnnouncement)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SocialNetworkPackagePackage.MESSAGE_POST__PUBLICANNOUNCEMENT:
				return publicannouncement != null;
		}
		return super.eIsSet(featureID);
	}

} //MessagePostImpl
